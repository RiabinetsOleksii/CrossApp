﻿param([string]$ProjectRoot = '')
$ErrorActionPreference = 'Stop'

function Find-CrossAppRoot {
    param([string]$Requested)
    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($Requested)) { $candidates += $Requested }
    $candidates += @((Split-Path -Parent $PSScriptRoot), (Get-Location).Path, (Join-Path $HOME 'CrossApp'))
    foreach ($candidate in $candidates) {
        $full = [IO.Path]::GetFullPath($candidate)
        if (Test-Path -LiteralPath (Join-Path $full 'CrossApp.slnx') -PathType Leaf) { return $full }
    }
    throw 'CrossApp.slnx не знайдено. Розпакуй lab09-package у CrossApp або запусти: .\install-lab09.ps1 -ProjectRoot C:\Users\rabin\CrossApp'
}
$project = Find-CrossAppRoot $ProjectRoot
$payload = Join-Path $PSScriptRoot 'payload'
$utf8 = New-Object System.Text.UTF8Encoding($false)
$programPath = Join-Path $project 'src/Cli/Program.cs'
$lab08Path = Join-Path $project 'src/Cli/Lab08Demo.cs'
$storePath = Join-Path $project 'src/Core/Storage/FileSensorStore.cs'
$projectPath = Join-Path $project 'src/Cli/Cli.csproj'
$readmePath = Join-Path $project 'README.md'
$ignorePath = Join-Path $project '.gitignore'

# Preflight: no files changed until the exact Lab 8 integration points are found.
foreach ($relative in @(
    'src/Cli/Cli.csproj', 'src/Cli/Program.cs', 'src/Cli/Lab08Demo.cs',
    'src/Core/Storage/FileSensorStore.cs', 'src/Core/Import/JsonSensorImporter.cs',
    'src/Core/Services/SensorService.cs', 'src/Core/Domain/Sensor.cs',
    'tests/Core.Tests/Core.Tests.csproj', 'README.md', '.gitignore')) {
    if (-not (Test-Path -LiteralPath (Join-Path $project $relative) -PathType Leaf)) {
        throw "Відсутній $relative. Потрібен CrossApp з лабораторною 8; нічого не змінено."
    }
}
$program = [IO.File]::ReadAllText($programPath)
$lab08 = [IO.File]::ReadAllText($lab08Path)
$store = [IO.File]::ReadAllText($storePath)
$csproj = [IO.File]::ReadAllText($projectPath)
if (-not $program.Contains('Lab08Demo.RunAsync(args)') -or
    -not $program.Contains('Console.OutputEncoding = Encoding.UTF8;') -or
    -not $program.Contains('return Path.Combine(FindRepositoryRoot(), "data", "sensors.json");') -and
    -not $program.Contains('return Lab09Configuration.Load(args).DataFile;')) {
    throw 'Program.cs має іншу структуру. Інсталятор зупинено без змін — потрібна ручна адаптація.'
}
if (-not $lab08.Contains('public static async Task RunAsync(string[] args)')) {
    throw 'Lab08Demo.cs не відповідає очікуваній лабораторній 8. Нічого не змінено.'
}
if (-not $store.Contains('File.WriteAllText(_path, JsonSerializer.Serialize(dtos, Options));') -and
    -not $store.Contains('public int ExportSnapshot()')) {
    throw 'FileSensorStore.cs має іншу реалізацію. Нічого не змінено.'
}
if (-not $csproj.Contains('<TargetFrameworks>net8.0;net10.0</TargetFrameworks>')) {
    throw 'Очікувався multi-target Cli: net8.0;net10.0. Нічого не змінено.'
}

$backup = Join-Path $project ('.lab09-backups/' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
function Backup([string]$path) {
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $relative = $path.Substring($project.Length).TrimStart([char]'\', [char]'/')
        $destination = Join-Path $backup $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
        Copy-Item -LiteralPath $path -Destination $destination -Force
    }
}
function Save([string]$path, [string]$content) {
    [IO.File]::WriteAllText($path, $content, $utf8)
}

Write-Host '=== CrossApp: install Lab 09 ===' -ForegroundColor Cyan
Write-Host "Project: $project"
foreach ($file in (Get-ChildItem -LiteralPath $payload -Recurse -File)) {
    $relative = $file.FullName.Substring($payload.Length).TrimStart([char]'\', [char]'/')
    $destination = Join-Path $project $relative
    Backup $destination
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
    Write-Host "  + $relative"
}

# Existing Lab 5 FileSensorStore: maintain the same ISensorStore API and JSON schema.
$store = [IO.File]::ReadAllText($storePath)
if (-not $store.Contains('public int ExportSnapshot()')) {
    Backup $storePath
    if (-not $store.Contains('using System.Text.Encodings.Web;')) {
        $store = $store.Replace('using System.Text.Json;', "using System.Text.Encodings.Web;`r`nusing System.Text.Json;")
    }
    $serialConfig = @'
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
'@
    $store = $store.Replace('        WriteIndented = true,', $serialConfig.TrimEnd())
    $oldWrite = '        File.WriteAllText(_path, JsonSerializer.Serialize(dtos, Options));'
    $newWrite = @'
        var temp = _path + ".tmp";
        try
        {
            File.WriteAllText(temp, JsonSerializer.Serialize(dtos, Options));
            File.Move(temp, _path, overwrite: true);
        }
        finally
        {
            if (File.Exists(temp)) File.Delete(temp);
        }
'@
    $store = $store.Replace($oldWrite, $newWrite.TrimEnd())
    $anchor = '    public IReadOnlyList<Sensor> List()'
    $export = @'
    // Lab 9: export the full collection with the same atomic JSON writer.
    public int ExportSnapshot()
    {
        EnsureLoaded();
        Flush();
        return _cache.Count;
    }

'@
    $store = $store.Replace($anchor, $export + $anchor)
    Save $storePath $store
    Write-Host '  * FileSensorStore: atomic .tmp+File.Move, camelCase, readable Cyrillic, export'
}

# Program: Lab 9 CLI route and configuration-backed default store path.
$program = [IO.File]::ReadAllText($programPath)
if (-not $program.Contains('Lab09Demo.RunAsync(args)')) {
    Backup $programPath
    $dispatch = @'

// Lab 9: portable JSON, profiles, secrets and optional CLI configuration.
// Both `--lab09 export` and `export` work (the latter matches the worksheet).
if (args.Contains("--lab09", StringComparer.OrdinalIgnoreCase) ||
    args.Any(a => a.Equals("config", StringComparison.OrdinalIgnoreCase) ||
                  a.Equals("export", StringComparison.OrdinalIgnoreCase) ||
                  a.Equals("import", StringComparison.OrdinalIgnoreCase)))
{
    await Lab09Demo.RunAsync(args);
    return;
}
'@
    $program = $program.Replace('Console.OutputEncoding = Encoding.UTF8;',
        'Console.OutputEncoding = Encoding.UTF8;' + $dispatch)
}
# Upgrade an existing Lab 9 installation without duplicating the dispatch.
if ($program.Contains('if (args.Contains("--lab09", StringComparer.OrdinalIgnoreCase))')) {
    $old = 'if (args.Contains("--lab09", StringComparer.OrdinalIgnoreCase))'
    $new = @'
if (args.Contains("--lab09", StringComparer.OrdinalIgnoreCase) ||
    args.Any(a => a.Equals("config", StringComparison.OrdinalIgnoreCase) ||
                  a.Equals("export", StringComparison.OrdinalIgnoreCase) ||
                  a.Equals("import", StringComparison.OrdinalIgnoreCase)))
'@
    $new = $new.TrimEnd()
    $program = $program.Replace($old, $new)
}
$program = $program.Replace(
    'return Path.Combine(FindRepositoryRoot(), "data", "sensors.json");',
    'return Lab09Configuration.Load(args).DataFile;')
$program = $program.Replace('private static string FindRepositoryRoot()',
                            'internal static string FindRepositoryRoot()')
$oldError = 'throw new DirectoryNotFoundException("Не знайдено CrossApp.slnx; запусти програму з папки CrossApp.");'
$program = $program.Replace($oldError, 'return AppContext.BaseDirectory; // Published application without solution files.')
Save $programPath $program
Write-Host '  * Program: --lab09 route, config-backed default path, publish fallback'

# Lab 8 remains intact; only its sample JSON defaults become cwd-independent.
$lab08 = [IO.File]::ReadAllText($lab08Path)
if ($lab08.Contains('Path.Combine("data", "lab08-valid.json")')) {
    Backup $lab08Path
    $lab08 = $lab08.Replace('Path.Combine("data", "lab08-valid.json")',
        'Path.Combine(ProjectPaths.FindRepositoryRoot(), "data", "lab08-valid.json")')
    $lab08 = $lab08.Replace('Path.Combine("data", "lab08-invalid.json")',
        'Path.Combine(ProjectPaths.FindRepositoryRoot(), "data", "lab08-invalid.json")')
    Save $lab08Path $lab08
    Write-Host '  * Lab08Demo: sample paths independent of cwd'
}

# NuGet packages are needed only by the CLI, never by Core.
$csproj = [IO.File]::ReadAllText($projectPath)
$addedCsproj = $false
if (-not $csproj.Contains('<UserSecretsId>')) {
    # Unique per repository/user; never regenerate if an ID already exists.
    $secretsId = [Guid]::NewGuid().ToString()
    $csproj = $csproj.Replace('</PropertyGroup>',
        "    <UserSecretsId>$secretsId</UserSecretsId>`r`n  </PropertyGroup>")
    $addedCsproj = $true
}
if (-not $csproj.Contains('appsettings*.json')) {
    $content = @'
  <ItemGroup>
    <None Update="appsettings*.json">
      <CopyToOutputDirectory>PreserveNewest</CopyToOutputDirectory>
      <CopyToPublishDirectory>PreserveNewest</CopyToPublishDirectory>
    </None>
  </ItemGroup>
'@
    $csproj = $csproj.Replace('</Project>', $content + "`r`n</Project>")
    $addedCsproj = $true
}
$packages = @(
    'Microsoft.Extensions.Configuration',
    'Microsoft.Extensions.Configuration.Json',
    'Microsoft.Extensions.Configuration.EnvironmentVariables',
    'Microsoft.Extensions.Configuration.Binder',
    'Microsoft.Extensions.Configuration.UserSecrets',
    'Microsoft.Extensions.Configuration.CommandLine',
    'Microsoft.Extensions.Configuration.FileExtensions'
)
$toAdd = @($packages | Where-Object { $csproj -notmatch ('Include="' + [regex]::Escape($_) + '"') })
if ($toAdd.Count -gt 0) {
    $refs = ($toAdd | ForEach-Object { '    <PackageReference Include="' + $_ + '" Version="10.0.0" />' }) -join "`r`n"
    $csproj = $csproj.Replace('</Project>', "  <ItemGroup>`r`n$refs`r`n  </ItemGroup>`r`n</Project>")
    $addedCsproj = $true
}
if ($addedCsproj) {
    Backup $projectPath
    Save $projectPath $csproj
    Write-Host '  * Cli.csproj: config providers, user-secrets ID, appsettings CopyToOutputDirectory'
}

$readme = [IO.File]::ReadAllText($readmePath)
$marker = '<!-- LAB09-SECTION-START -->'
if (-not $readme.Contains($marker)) {
    Backup $readmePath
    $section = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'README_LAB09_APPEND.md'))
    Save $readmePath ($readme.TrimEnd() + "`r`n`r`n" + $marker + "`r`n" + $section.Trim() + "`r`n")
    Write-Host '  * README: Lab 9 documentation'
}
$ignore = [IO.File]::ReadAllText($ignorePath)
$needed = @('/.lab09-backups/', '/lab09-package/', '/CrossApp_Lab09_Complete.zip',
            '/data/lab09-*.json', '/src/Cli/appsettings.Local.json',
            '/src/Cli/appsettings.*.local.json', '**/secrets.json')
$missing = @($needed | Where-Object { -not $ignore.Contains($_) })
if ($missing.Count -gt 0) {
    Backup $ignorePath
    Save $ignorePath ($ignore.TrimEnd() + "`r`n# Lab 9: installer, generated data, local-only secrets`r`n" + ($missing -join "`r`n") + "`r`n")
    Write-Host '  * .gitignore: backups, runtime files and secrets'
}

Write-Host "Backups: $backup" -ForegroundColor Yellow
Write-Host 'NEXT: dotnet restore src/Cli/Cli.csproj' -ForegroundColor Green
Write-Host 'NEXT: dotnet build src/Cli/Cli.csproj -f net8.0' -ForegroundColor Green
Write-Host 'NEXT: dotnet test tests/Core.Tests/Core.Tests.csproj -f net8.0' -ForegroundColor Green
Write-Host 'NEXT: powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\lab09-check.ps1' -ForegroundColor Green
Write-Host 'NOTE: Windows Smart App Control can block execution of newly built DLLs even after a successful build.' -ForegroundColor Yellow
