@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-lab09.ps1"
echo.
echo Lab09 installer finished. Check messages above for next steps.
pause
