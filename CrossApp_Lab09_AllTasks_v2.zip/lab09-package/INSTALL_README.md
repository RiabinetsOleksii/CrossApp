# CROSSAPP — Лабораторна робота №9 (розширена комплектація, v2)

Пакет пристосовано до CrossApp після лабораторної №8 (IoT-сенсори, .NET 8/10).

## Встановлення (без видалення попередніх файлів)

1. Розпакуй ZIP. Отримаєш папку **lab09-package**.
2. Відкрий `lab09-package` та двічі клацни **INSTALL_LAB09.cmd**. Або відкрий PowerShell у папці `lab09-package` та виконай:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-lab09.ps1 -ProjectRoot C:\Users\rabin\CrossApp
```

3. Інсталятор знайде CrossApp, перевірить наявність коду лабораторної №8, створить резервні копії в `.lab09-backups/` і додасть лабораторну №9. **Дані сенсорів не видаляються, Git-коміти не створюються автоматично.**

## Перший запуск

```powershell
cd C:\Users\rabin\CrossApp
dotnet restore src/Cli/Cli.csproj
dotnet build src/Cli/Cli.csproj -f net8.0
dotnet test tests/Core.Tests/Core.Tests.csproj -f net8.0
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\lab09-check.ps1
```

## Демонстрація

```powershell
dotnet run --project src/Cli/Cli.csproj -f net8.0 -- --lab09 config
dotnet run --project src/Cli/Cli.csproj -f net8.0 -- --lab09 export
dotnet run --project src/Cli/Cli.csproj -f net8.0 -- --lab09 import
```

**Не копіюй у Git** `.lab09-backups/`, файли `secrets.json` або згенеровані дані. Для прикладу user-secrets запусти локально:

```powershell
dotnet user-secrets set "Integration:ApiKey" "YOUR_LOCAL_DEMO_VALUE" --project src/Cli
```

## Які файли змінюються

Мінімально: `src/Cli/Program.cs`, `src/Cli/Lab08Demo.cs` (шляхи до прикладів), `src/Cli/Cli.csproj`, `src/Core/Storage/FileSensorStore.cs`, `README.md`, `.gitignore`. Додаються `AppOptions.cs`, `Lab09Configuration.cs`, `Lab09Demo.cs`, три `appsettings*.json`, нові unit-тести, перевірка та документи.

**Відоме обмеження твого ПК:** Smart App Control може заблокувати нові DLL (`0x800711C7`). Цей пакет не вимикає захист Windows; якщо блокування залишиться, перевірки потрібно запускати у дозволеному середовищі, наприклад WSL з установленим .NET 8 SDK.

## Коміт після успішних перевірок

```powershell
git status
git add README.md .gitignore src tests scripts/lab09-check.ps1 docs/lab09-report.md docs/lab09-defense.md docs/lab09-questions.md
git diff --cached --stat
git commit -m "lab09"
git push origin main
```


## Що додано у v2

- Прямі команди `export`, `import`, `config` без `--lab09`, як в методичці.
- Автоматична перевірка опційного `AddCommandLine` і пріоритету CLI-аргументів.
- Два додаткові xUnit-тести: експорт **усієї** колекції і створення каталогу.
- `docs/lab09-all-tasks-checklist.md` із зіставленням кожного пункту методички.
- Інсталятор може повторно застосувати зміни поверх першого пакета Lab09.

Важливо: у PDF методички №9 **немає окремого переліку додаткових завдань**. `AddCommandLine` позначено як опційне, і воно виконане.
